import styles from '../styles/Sheep.module.css'
import React,{useState,useEffect} from 'react';
//asasasa+

export default function pagenotfound() {

 
  let initialState={
    quote:"",
    name:""
  }

  const [quote, setquote] = useState(initialState)
let quotes=[
{
    "quote": "It\u2019s not the years in your life that count. It\u2019s the life in your years.",
    "name": "Abraham Lincoln"
},
{
    "quote": "Change your thoughts and you change your world.",
    "name": "Norman Vincent Peale"
},
{
    "quote": "Either write something worth reading or do something worth writing.",
    "name": "Benjamin Franklin"
},
{
    "quote": "Nothing is impossible, the word itself says, \u201cI\u2019m possible!\u201d",
    "name": "\u2013Audrey Hepburn"
},
{
    "quote": "The only way to do great work is to love what you do.",
    "name": "Steve Jobs"
},
{
    "quote": "If you can dream it, you can achieve it.",
    "name": "Zig Ziglar"
},
{
    "quote": "What lies behind us and what lies before us are tiny matters compared to  what lies within us.",
    "name": "Ralph Waldo Emerson"
},
{
    "quote": "No one can make you feel inferior without your consent.",
    "name": "Eleanor Roosevelt"
}
]
let generateQuote=()=>{
  console.log(quotes.length);
  var random = Math.floor(Math.random() * (quotes.length - 0) ) + 0;
  console.log(random);
  setquote(quotes[random])

}
  useEffect(() => {
      generateQuote();
  }, [])

    return (
      <div class={styles.body}>
          <div class="container-fluid text-center">
   
          <h1 class={styles.h1} >404</h1>
        <br/>   
     <div class={styles.grid}>
 
 <img class={styles.img} src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQNGiJkwwLOlNv5x4fzxu5K-_NEBuGeHLoCHETuCFedJngoteSwxA"/>
 <img class={styles.kirby} src="http://media0.giphy.com/media/Vl15AaFeM9ZjW/giphy.gif"/>
 <br/>
 </div>
 <div class="container">
        <h1>MASTER LLEGASTE MUY LEJOS 404</h1>
        <div class="wrapper" id="quote-box">
          <h2 id="text">{quote.quote}</h2>
          <br />
          <div>
          <h3 id="author">{quote.name}</h3>
          </div>
        <div class={styles.grid}>
        <button class={styles.button} onClick={generateQuote}>Next Quote</button>
        </div>
        </div>
      </div>

 </div>
      </div>
  
   
            )
    }
  
